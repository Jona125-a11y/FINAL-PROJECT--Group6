<script src="js/click.js"></script>
    <script src="js/scroll.js"></script>
    <script src="js/update_paid.js"></script>
</body>
</html>