<script src="js/click.js"></script>
    <script src="js/scroll.js"></script>
</body>
</html>